package payroll;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class UnitTests {
	
	private boolean sortByID = false;
	
	// Imported from Payroll.java
	
	private int compareEmployees(Employee e1, Employee e2) {
		if (sortByID) return Integer.compare(e1.getIdNumber(), e2.getIdNumber());
		
		int last = e1.getLastName().compareToIgnoreCase(e2.getLastName());
		if (last != 0) return last;
		
		int first = e1.getFirstName().compareToIgnoreCase(e2.getFirstName());
		if (first != 0) return first;
		
		return Integer.compare(e1.getIdNumber(), e2.getIdNumber());
	}
	
	private int partition(Employee[] employees, int low, int high) {
	    Employee pivot = employees[(low + high) / 2];
	    
	    while (true) {
	        while (compareEmployees(employees[low], pivot) < 0) low++;
	        while (compareEmployees(employees[high], pivot) > 0) high--;
	        if (low >= high) return high;
	        
	        Employee temp = employees[low];
	        employees[low] = employees[high];
	        employees[high] = temp;
	        low++;
	        high--;
	    }
	}

	private void quickSort(Employee[] employees, int low, int high) {
	    if (low >= 0 && high >= 0 && low < high) {
	        int p = partition(employees, low, high);
	        
	        quickSort(employees, low, p);
	        quickSort(employees, p + 1, high);
	    }
	}

	private int seqSearch(Employee[] employees, String lastName) {
	    for (int i = 0; i < employees.length; i++) {
	    	String currentLast = employees[i].getLastName();
	    	
	        if (currentLast.equalsIgnoreCase(lastName)) {
	            return i;
	        }
	    }
	    return -1;
	}
	
	/**
	 * Test 1 makes sure the program can create salaried employees.
	 * 
	 * @throws Exception
	 */
	
	@Test
	public void test1() throws Exception {		
		assertEquals("Salaried, Base: $5,000.11: ID: 1 - Poe, Pauline", new SalariedEmployee("Pauline", "Poe", 5000.11f).toString());
		assertEquals("Salaried, Base: $4,500.10: ID: 2 - Smith, John", new SalariedEmployee("John", "Smith", 4500.1f).toString());
		assertEquals("Salaried, Base: $10,000.01: ID: 3 - Doe, Jane", new SalariedEmployee("Jane", "Doe", 10000.01f).toString());
	}
	
	/**
	 * Test 2 makes sure the program can create hourly employees.
	 * 
	 * @throws Exception
	 */
	
	@Test
	public void test2() throws Exception {		
		assertEquals("Hourly: 12.12; ID: 4 - Blue, Tim", new HourlyEmployee("Tim", "Blue", 12.12f).toString());
		assertEquals("Hourly: 24.32; ID: 5 - Red, Tom", new HourlyEmployee("Tom", "Red", 24.32f).toString());
		assertEquals("Hourly: 36.01; ID: 6 - Green, Ted", new HourlyEmployee("Ted", "Green", 36.01f).toString());
	}
	
	/**
	 * Test 3 makes sure employees can be properly sorted and searched
	 * 
	 * @throws Exception
	 */
	
	@Test
	public void test3() throws Exception {
		Employee[] employees = {
				new SalariedEmployee("Pauline", "Poe", 5000),
			    new SalariedEmployee("John", "Smith", 4500),
			    new SalariedEmployee("Jane", "Doe", 10000),
			    new HourlyEmployee("Tim", "Blue", 12),
			    new HourlyEmployee("Tom", "Red", 24),
			    new HourlyEmployee("Ted", "Green", 36)
		};
		
		quickSort(employees, 0, employees.length - 1);

		assertEquals("Blue", employees[0].getLastName());
		assertEquals("Doe", employees[1].getLastName());
		assertEquals("Green", employees[2].getLastName());
		assertEquals("Poe", employees[3].getLastName());
		assertEquals("Red", employees[4].getLastName());
		assertEquals("Smith", employees[5].getLastName());

		int index = seqSearch(employees, "Red");
		assertEquals(4, index);
	}
}
